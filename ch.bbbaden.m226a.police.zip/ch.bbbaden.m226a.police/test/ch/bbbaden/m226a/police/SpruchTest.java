/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.m226a.police;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Endrit Gashi
 */
public class SpruchTest {
    
    @Test
    public void testgetSpruch(){
    final double alkoholPromille = 1.0;
    final Spruch testSpruch = new Spruch(alkoholPromille);
    
    final String spruch = testSpruch.getSpruch();
    
    assertEquals("Spruch","Sie dürfen nicht fahren.",spruch);
    }
}
