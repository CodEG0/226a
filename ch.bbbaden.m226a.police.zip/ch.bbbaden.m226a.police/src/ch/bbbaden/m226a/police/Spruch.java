/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.m226a.police;

/**
 *
 * @author Endrit Gashi
 */
public class Spruch {
    double alkoholPromille;

    public Spruch(double alkoholPromille) {
        this.alkoholPromille = alkoholPromille;
    }

    public String getSpruch(){
        if (alkoholPromille > 0.8) {
            return "Sie dürfen nicht fahren.";
        }else{
            return "Sie dürfen weiter fahren.";
        }
    }
    
}
