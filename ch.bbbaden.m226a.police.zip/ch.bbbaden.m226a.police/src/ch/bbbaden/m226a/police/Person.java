/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.m226a.police;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;

/**
 *
 * @author Endrit Gashi
 */
public class Person {

    public final int MAENNLICH = 0;
    public final int WEIBLICH = 1;
    private final double ABBAU_WARTEZEIT_STUNDEN = 1.0;
    private final double ABBAU_PRO_STUNDE = 0.1;
    private final double ANTEIL_WASSER_IM_BLUT = 0.8;
    private final double DICHTE_BLUT_GRAMM_PRO_CCM = 1.055;
    private double koerpermasse;
    private double koerpergrosseInCm;
    private java.util.Date geburtsdatum;
    private int geschlecht;
    private double alkoholPromille = 0.0;

    public Person(double koerpermasse, double koerpergrosseInCm, Date geburtsdatum, int geschlecht) {
        this.koerpermasse = koerpermasse;
        this.koerpergrosseInCm = koerpergrosseInCm;
        this.geburtsdatum = geburtsdatum;
        this.geschlecht = geschlecht;
    }

    private double getAlterInJahren() {
        final LocalDate jetzt = LocalDate.now();
        final LocalDate localGeburtsdatum = geburtsdatum.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        final Period period = Period.between(localGeburtsdatum, jetzt);
        final long days = ChronoUnit.DAYS.between(localGeburtsdatum, jetzt);
        return days / 365.0;
    }
    
    public void trinke(AlkoholischesGetraenk alkoholischesGetraenk){
        alkoholPromille = (alkoholischesGetraenk.getAlkoholMasseInGramm()) * ANTEIL_WASSER_IM_BLUT * DICHTE_BLUT_GRAMM_PRO_CCM * getGKW(); 
    }

    
    public double getAlkoholPromille(){
        return alkoholPromille;
    }
    
    private double getGKW(){
        if (geschlecht == 0) {
            
            return 2.447-(0.09516 * getAlterInJahren())+(0.1074 * koerpergrosseInCm)+(0.3362*koerpermasse);  
        } else {
            return 0.203-(0.07 * getAlterInJahren())+(0.1069 * koerpergrosseInCm)+(0.2466*koerpermasse);  
        
        }
    }
}
