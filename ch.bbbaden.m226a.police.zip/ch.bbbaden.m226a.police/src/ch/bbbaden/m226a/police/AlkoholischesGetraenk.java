/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.m226a.police;

import java.util.Date;

/**
 *
 * @author Endrit Gashi
 */
public class AlkoholischesGetraenk {
    public final double BIER_ALKOHOLGEHALT = 0.05;
    public final double WEIN_ALKOHOLGEHALT = 0.10;
    public final double SCHNAPS_ALKOHOLGEHALT = 0.40;
    private final double DICHTE_ALKOHOL = 0.8;
    private int volumenInMilliLiter;
    private double alkoholgehalt;
    private java.util.Date getrunkenAm;

    public AlkoholischesGetraenk(int volumenInMilliLiter, double alkoholgehalt, Date getrunkenAm) {
        this.volumenInMilliLiter = volumenInMilliLiter;
        this.alkoholgehalt = alkoholgehalt;
        this.getrunkenAm = getrunkenAm;
    }
    
    public double getStundenSeitEinnahme(Date jetzt){
        long timeDifferenceMilli = jetzt.getTime()- getrunkenAm.getTime();
        long timeDifferenceStunden = timeDifferenceMilli / 3600000;
        return timeDifferenceStunden;
    }
    
    public double getAlkoholMasseInGramm(){
        return volumenInMilliLiter * alkoholgehalt * DICHTE_ALKOHOL;
    }
    
}
