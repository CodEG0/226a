/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.m226a.police;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Endrit Gashi
 */
public class GUI {

    private Person askPersonData() {
        double koerpermasse = Double.parseDouble(JOptionPane.showInputDialog(null, "Geben Sie Ihr Gewicht in kg ein.", "Gewicht", JOptionPane.INFORMATION_MESSAGE));
        double koerpergroesseInCm = Double.parseDouble(JOptionPane.showInputDialog(null, "Geben Sie Ihre Grösse in cm ein.", "Grösse", JOptionPane.INFORMATION_MESSAGE));
        Date geburtsdatum = askGeburtsdatum();
        int geschlecht = askGeschlecht();

        Person person = new Person(koerpermasse, koerpergroesseInCm, geburtsdatum, geschlecht);
        return person;
    }
    
    private AlkoholischesGetraenk askAlkoholischesGetraenkData(Date trinkDatum) {
        int volumenInMilliLiter = Integer.parseInt(JOptionPane.showInputDialog(null, "Geben Sie die getrunkene Menge in Milliliter ein.", "Trinkmenge", JOptionPane.INFORMATION_MESSAGE));
        double alkoholgehalt = askAlkoholgehalt();
        trinkDatum = askTrinkDatum();

        AlkoholischesGetraenk alkoholischesGetraenk = new AlkoholischesGetraenk(volumenInMilliLiter, alkoholgehalt, trinkDatum);

        return alkoholischesGetraenk;
    }

    public void promilleRechner() {
            askPersonData();
            askAlkoholischesGetraenkData(askTrinkDatum());
            Spruch spruch = new Spruch(askPersonData().getAlkoholPromille());
            JOptionPane.showMessageDialog(null, "Promillegehalt:" + askPersonData().getAlkoholPromille() + spruch, "Resultat",JOptionPane.QUESTION_MESSAGE);
           
    }
    

    private Date askGeburtsdatum() {
        Date geburtsdatum = null;
        final DateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        final Date jetzt = new Date();
        do {
            final String eingabe = JOptionPane.showInputDialog(null, "Geben Sie Ihr Geburtsdatum ein.",
                    "Geburtsdatum",
                    JOptionPane.QUESTION_MESSAGE);

            if (eingabe == null) { // Cancel
                System.exit(0);
            }
            try {
                geburtsdatum = formatter.parse(eingabe);
            } catch (ParseException ex) {
                JOptionPane.showMessageDialog(null, eingabe + " ist kein gültiges Datum.");
            }
        } while (!jetzt.after(geburtsdatum));
        return geburtsdatum;
    }

    private int askGeschlecht() {
        String[] options = {"Männlich", "Weiblich"};
        int geschlecht = JOptionPane.showOptionDialog(null, "Wählen Sie Ihr Geschlecht", "Geschlecht", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);;
        return geschlecht;
    }

    
    private double askAlkoholgehalt() {
        double alkoholgehalt = 0.0;
        String[] options = {"Bier", "Wein", "Schnaps"};
        int alkoholgehalt1 = JOptionPane.showOptionDialog(null, "Was für ein Getränk haben Sie getrunken?", "Getränk", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);;
        if (alkoholgehalt1 == 0) {
            alkoholgehalt = 0.05;
        } else if (alkoholgehalt1 == 1) {
            alkoholgehalt = 0.10;
        } else if (alkoholgehalt1 == 2) {
            alkoholgehalt = 0.40;
        }
        return alkoholgehalt;
    }

    private Date askTrinkDatum() {
        Date trinkDatum = null;
        final DateFormat formatter = new SimpleDateFormat("dd.MM.yyyy kk:mm");
        final Date jetzt = new Date();
        do {
            final String eingabe = JOptionPane.showInputDialog(null, "Geben Sie Trinkdatum und -zeit ein.",
                    "Trinkzeit",
                    JOptionPane.QUESTION_MESSAGE);
            if (eingabe == null) { // Cancel
                System.exit(0);
            }
            try {
                trinkDatum = formatter.parse(eingabe);
            } catch (ParseException ex) {
                JOptionPane.showMessageDialog(null, eingabe + " ist keine gültige Trinkzeit.");
            }
        } while (trinkDatum == null || !jetzt.after(trinkDatum));
        return trinkDatum;
    }

}
